const Quiz_arr=[
    {question:"Q1. What does HTML stand for?",
    a:"Hyperlinks and Text Markup Language",
    b:"Hypertext Markup Language",
    c:"Hypermedia Text Markup Language",
    d:"None of the above",
    ans:"ans2"},
    
    {question:"Q2. Which property is used to change the background color of an HTML element in CSS?",
    a:"text-color",
    b:"background-image",
    c:"background-color",
    d:"color",
    ans:"ans3"},
    
    {question:"Q3. What is the purpose of the 'script' tag in HTML?",
    a:"To define a style for an HTML element",
    b:"To create a new HTML element",
    c:"To link to an external JavaScript file",
    d:"To define a paragraph of text",
    ans:"ans3"},
    
    {question:"Q4. Which JavaScript method is used to add an element to the end of an array?",
    a:"shift()",
    b:"push()",
    c:"unshift()",
    d:"pop()",
    ans:"ans2"},
    
    {question:"Q5. What is the purpose of the 'document.getElementById' method in JavaScript?",
    a:"To change the style of an HTML element",
    b:"To add a new HTML element to the document",
    c:"To retrieve an HTML element from the document",
    d:"None of the above",
    ans:"ans3"},
];

const question=document.querySelector("#question")
const option1=document.querySelector("#option1")
const option2=document.querySelector("#option2")
const option3=document.querySelector("#option3")
const option4=document.querySelector("#option4")
const submit =document.querySelector("#submit")
const answers=document.querySelectorAll(".answer")
const showscore=document.querySelector("#score");
const divscore=document.querySelector("#play");
const username=document.querySelector("#name");
//console.log(Quiz_arr[0].question);

let question_count=0;
let score=0;

function uname()
{
    user=prompt("Enter your name:");
}
uname();

username.innerHTML=`Welcome ${user} in Sea Of Quizzes`;


function loadquiz()
{
       question.innerHTML=Quiz_arr[question_count].question
       option1.innerHTML=Quiz_arr[question_count].a
       option2.innerHTML=Quiz_arr[question_count].b
       option3.innerHTML=Quiz_arr[question_count].c
       option4.innerHTML=Quiz_arr[question_count].d
}

loadquiz();
//question_count+=1;
const getcheckedans = () => {
    let answer;

    answers.forEach((checkedans) => {
        if(checkedans.checked){
            answer=checkedans.id;
        }
    });
    return answer;
 };

 const restartstate = () =>{

    answers.forEach((checkedans) =>
    {
        checkedans.checked=false;
    } 
    )
 }

 submit.addEventListener('click',()=>{
    const chekedAns= getcheckedans();
    //console.log(chekedAns);
    if(chekedAns == Quiz_arr[question_count].ans)
    {
        score++;
        showscore.innerHTML="Your Score:"+ score;
    };

    restartstate();

    question_count++;
    if(question_count < Quiz_arr.length)
    {
        loadquiz();
    }
    else
    {
        showscore.innerHTML=`<h3> You scored ${score}/${Quiz_arr.length}</h3>`;
        if(score == Quiz_arr.length)
        {
            divscore.innerHTML=`<h4>Excellent-You are Genius</h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
        else if(score == 0)
        {
            divscore.innerHTML=`<h4>Better Luck Next Time</h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
        else
        {
            divscore.innerHTML=`<h4>You Played Good </h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
       // divscore.innerHTML=<h4>Hope You Enjoyed It.....</h4>;
        //<button class="btn" onclick="location.reload()">Play Again</button>;

    divscore.classList.remove('again');
    }
 })
