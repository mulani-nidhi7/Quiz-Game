const Quiz_arr=[
    {question:"Q1.What is Python?",
a:"A high-level programming language.",
b:"A low-level programming language.",
c:"A markup language for creating web pages.",
d:"None of the above.",
ans:"ans1"},

{question:"Q2.What is the purpose of indentation in Python?",
a:"To make the code look neat and organized.",
b:"To separate different sections of the code.",
c:"To indicate the start and end of a block of code.",
d:"None of the above.",
ans:"ans3"},

{question:"Q3.What is a Python module?",
a:"A group of Python files.",
b:"A set of pre-defined functions and classes that can be imported and used in a Python program.",
c:"A tool for debugging Python code.",
d:"None of the above.",
ans:"ans2"},

{question:"Q4.What is the purpose of a Python virtual environment?",
a:"To isolate the dependencies and packages used by a Python project.",
b:"To create a virtual machine for running Python code.",
c:"To allow multiple versions of Python to coexist on the same machine.",
d:"None of the above.",
ans:"ans1"},

{question:"Q5.What is the difference between a list and a tuple in Python?",
a:"A list is mutable, while a tuple is immutable.",
b:"A list can hold multiple data types, while a tuple can only hold one data type.",
c:"A list is ordered, while a tuple is unordered.",
d:"None of the above.",
ans:"ans1"},
];

const question=document.querySelector("#question")
const option1=document.querySelector("#option1")
const option2=document.querySelector("#option2")
const option3=document.querySelector("#option3")
const option4=document.querySelector("#option4")
const submit =document.querySelector("#submit")
const answers=document.querySelectorAll(".answer")
const showscore=document.querySelector("#score");
const divscore=document.querySelector("#play");
const username=document.querySelector("#name");
console.log(Quiz_arr[0].question);

let question_count=0;
let score=0;

function uname()
{
    user=prompt("Enter your name:");
}
uname();
username.innerHTML=`Welcome ${user} in Sea Of Quizzes`;

function loadquiz()
{
       question.innerHTML=Quiz_arr[question_count].question
       option1.innerHTML=Quiz_arr[question_count].a
       option2.innerHTML=Quiz_arr[question_count].b
       option3.innerHTML=Quiz_arr[question_count].c
       option4.innerHTML=Quiz_arr[question_count].d
}

loadquiz();
//question_count+=1;
const getcheckedans = () => {
    let answer;

    answers.forEach((checkedans) => {
        if(checkedans.checked){
            answer=checkedans.id;
        }
    });
    return answer;
 };

 const restartstate = () =>{

    answers.forEach((checkedans) =>
    {
        checkedans.checked=false;
    } 
    )
 }

 submit.addEventListener('click',()=>{
    const chekedAns= getcheckedans();
    //console.log(chekedAns);
    if(chekedAns == Quiz_arr[question_count].ans)
    {
        score++;
        showscore.innerHTML="Your Score:"+ score;
    };

    restartstate();

    question_count++;
    if(question_count < Quiz_arr.length)
    {
        loadquiz();
    }
    else
    {
        showscore.innerHTML=`<h3> You scored ${score}/${Quiz_arr.length}</h3>`;
        if(score == Quiz_arr.length)
        {
            divscore.innerHTML=`<h4>Excellent-You are Genius</h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
        else if(score == 0)
        {
            divscore.innerHTML=`<h4>Better Luck Next Time</h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
        else
        {
            divscore.innerHTML=`<h4>You Played Good </h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
       // divscore.innerHTML=<h4>Hope You Enjoyed It.....</h4>;
        //<button class="btn" onclick="location.reload()">Play Again</button>;

    divscore.classList.remove('again');
    }
 })
