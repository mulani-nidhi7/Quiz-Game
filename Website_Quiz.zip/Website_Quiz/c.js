const Quiz_arr=[
    {question:"Q1.What is the correct syntax for creating a function in JavaScript?",
a:"function = myFunction()",
b:"function myFunction()",
c:"var myFunction = function()",
d:"All of the above",
ans:"ans2"},

{question:"Q1.What is the difference between a compiler and an interpreter?",
a:"A compiler translates code into machine language, while an interpreter executes code directly.",
b:"A compiler executes code directly, while an interpreter translates code into machine language.",
c:"A compiler and an interpreter are the same thing.",
d:"None of the above.",
ans:"ans1"},

{question:"Q2.What is a stack data structure?",
a:"A data structure where the first item added is the last item removed (Last In, First Out).",
b:"A data structure where the last item added is the last item removed (Last In, Last Out).",
c:"A data structure where the first item added is the first item removed (First In, First Out).",
d:"A data structure where the last item added is the first item removed (First In, Last Out).",
ans:"ans1"},

{question:"Q3.What is the difference between TCP and UDP?",
a:"TCP is a connection-oriented protocol that ensures reliable data delivery, while UDP is a connectionless protocol that does not guarantee delivery.",
b:"TCP is a connectionless protocol that does not guarantee delivery, while UDP is a connection-oriented protocol that ensures reliable data delivery.",
c:"TCP and UDP are the same thing.",
d:"None of the above.",
ans:"ans1"},

{question:"Q4.What is an algorithm?",
a:"A programming language.",
b:"A set of instructions for solving a problem or completing a task.",
c:"A data structure.",
d:"None of the above.",
ans:"ans2"},

{question:"Q5.What is the difference between a bit and a byte?",
a:"A bit is a unit of digital information that represents a 0 or a 1, while a byte is a collection of 8 bits.",
b:"A byte is a unit of digital information that represents a 0 or a 1, while a bit is a collection of 8 bytes.",
c:"A bit and a byte are the same thing.",
d:"None of the above.",
ans:"ans1"},
];

const question=document.querySelector("#question")
const option1=document.querySelector("#option1")
const option2=document.querySelector("#option2")
const option3=document.querySelector("#option3")
const option4=document.querySelector("#option4")
const submit =document.querySelector("#submit")
const answers=document.querySelectorAll(".answer")
const showscore=document.querySelector("#score");
const divscore=document.querySelector("#play");
const username=document.querySelector("#name");
console.log(Quiz_arr[0].question);

let question_count=0;
let score=0;

function uname()
{
    user=prompt("Enter your name:");
}
uname();
username.innerHTML=`Welcome ${user} in Sea Of Quizzes`;

function loadquiz()
{
       question.innerHTML=Quiz_arr[question_count].question
       option1.innerHTML=Quiz_arr[question_count].a
       option2.innerHTML=Quiz_arr[question_count].b
       option3.innerHTML=Quiz_arr[question_count].c
       option4.innerHTML=Quiz_arr[question_count].d
}

loadquiz();
//question_count+=1;
const getcheckedans = () => {
    let answer;

    answers.forEach((checkedans) => {
        if(checkedans.checked){
            answer=checkedans.id;
        }
    });
    return answer;
 };

 const restartstate = () =>{

    answers.forEach((checkedans) =>
    {
        checkedans.checked=false;
    } 
    )
 }

 submit.addEventListener('click',()=>{
    const chekedAns= getcheckedans();
    //console.log(chekedAns);
    if(chekedAns == Quiz_arr[question_count].ans)
    {
        score++;
        showscore.innerHTML="Your Score:"+ score;
    };

    restartstate();

    question_count++;
    if(question_count < Quiz_arr.length)
    {
        loadquiz();
    }
    else
    {
        showscore.innerHTML=`<h3> You scored ${score}/${Quiz_arr.length}</h3>`;
        if(score == Quiz_arr.length)
        {
            divscore.innerHTML=`<h4>Excellent-You are Genius</h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
        else if(score == 0)
        {
            divscore.innerHTML=`<h4>Better Luck Next Time</h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
        else
        {
            divscore.innerHTML=`<h4>You Played Good </h4>
            <button class="btn" onclick="location.reload()">Play Again</button>`;
        }
       // divscore.innerHTML=<h4>Hope You Enjoyed It.....</h4>;
        //<button class="btn" onclick="location.reload()">Play Again</button>;

    divscore.classList.remove('again');
    }
 })
